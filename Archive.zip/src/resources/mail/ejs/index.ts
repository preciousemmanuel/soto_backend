export const filePaths = {
  welcomeMail: "/src/resources/mail/ejs/welcomeMails/welcomeMail.ejs",
  verification: "",
  forgotPassword: "",
  sendOTP: "/src/resources/mail/ejs/sendOTP/sendOTP.ejs",
  sendMailsToVendors: "/src/resources/mail/ejs/sendMailsToVendors/sendMailsToVendors.ejs",

}