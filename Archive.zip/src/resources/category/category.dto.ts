

export interface FetchCategoriesDto {
  search?: string;
  limit?: number;
  page?: number
}






