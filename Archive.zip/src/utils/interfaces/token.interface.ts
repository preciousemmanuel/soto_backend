


interface Token extends Object {
  id: number;
  expires: number

}

export default Token;