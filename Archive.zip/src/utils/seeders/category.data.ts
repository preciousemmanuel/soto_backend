export const categorySeedData = [
  {
    name: "fashion"
  },
  {
    name: "electronics"
  },
  {
    name: "grocery"
  },
  {
    name: "home appliances"
  },
  {
    name: "phones and gadgets"
  },
  {
    name: "acessories"
  },
  {
    name: "jewelry"
  }
]